//Quest�o 01 
//Fa�a um programa em C que armazene 15 n�meros inteiros em um vetor NUM e imprima uma listagem dos n�meros lidos.

#include<stdio.h>
#include<stdlib.h>

main()

{
	int NUM[15], i;
	
	printf("\n\tDigite 15 numeros inteiros aleatorios: \n\n");
	
	for(i = 0 ; i < 15; ++i )
//++i � a mesma coisa que escrever i++;
	{
		printf("\nDigite os numeros na posicao %d = \t", i+1);
//linha 16, coloquei ( i + 1 ) para mostrar a posi��o exata que mostra, posi�ao 1, posi�a� 2  assim por diante.
		scanf("%d", &NUM[i] );
	}
		printf("\n\n\n");
//mostrar a lista completa
	for( i=0 ; i < 15 ; i++ )
	{
		printf("Posi�ao   %d   com o Numero = %d \t\t\n", i+1 , NUM[i]);
	}
}

