//Quest�o 03
//Fazer um algoritmo que leia os valores de um vetor inteiro de tamanho 10, e imprima o valor da soma dos n�meros �mpares presentes neste vetor.

#include<stdio.h>
#include<stdlib.h>

main()

{
	int vetor[10], x;
	int somaimpar=0 ;
	
	for( x = 0 ; x < 10 ; x++ )
	{
		printf("\n Digite 10 numero inteiro, posicao %d = ", x+1);
		scanf("%d", &vetor[x]);
	}

//CALCULO PARA SOMA DOS NUMEROS IMPARES;		
	printf("\n\nNumeros impares da lista");
		
	for( x = 0 ; x < 10 ; x++ )
		if( vetor[x] % 2 != 0)
		{
			somaimpar += vetor[x];

			printf("\nPosicao %d valor \t%d ", x+1 , vetor[x]);
		}	
		
	printf("\n\n\nSoma de todos is numeros impares sao: \t%d ", somaimpar);
	printf("\n");
}
