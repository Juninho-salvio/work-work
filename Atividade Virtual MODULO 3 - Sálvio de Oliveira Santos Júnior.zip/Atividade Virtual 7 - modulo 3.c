/*Quest�o 07 
Crie um programa que leia valores inteiros em uma matriz A[2][2] e em uma matriz B[2][2]. Gerar e imprimir a matriz SOMA[2][2].*/

#include<stdio.h>
#include<stdlib.h>

main()

{
	int matrizA[2][2], matrizB[2][2], soma[2][2], x, y;
	
	printf("\n\t MATRIZES 2 POR 2 : \n");
	
	for( x = 0 ; x < 2; x++ ){
		for( y = 0 ; y < 2 ; y++ )
		{
			printf("\nDigite numeros para Matriz A, posi��o %d por %d : \t", x+1, y+1);
			scanf("%d", &matrizA[x][y]);
			printf("\nDigite numeros para Matriz B, posi��o %d por %d : \t", x+1, y+1);
			scanf("%d", &matrizB[x][y]);
			printf("\n");
		}
	}
	printf("\n SOMA DAS MATRIZES: \n\n");
	
	for( x = 0 ; x < 2; x++ ){
		for( y = 0 ; y < 2 ; y++ )
		{
			soma[x][y] = matrizA[x][y] + matrizB[x][y];
			printf(" | %d | ", soma[x][y]);
		}	
	printf("\n");
	}
		
}
