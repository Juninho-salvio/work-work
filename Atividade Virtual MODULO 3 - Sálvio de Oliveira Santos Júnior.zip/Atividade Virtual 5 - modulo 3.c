//Quest�o 05 
//Crie um programa que leia o pre�o de compra e o pre�o de venda de 100 mercadorias (utilize vetores). 
//Ao final, o programa dever� imprimir quantas mercadorias proporcionam:
//�h Lucro < 10%
//�h 10% <= lucro <= 20%
//�h Lucro > 20%

#include<stdio.h>
#include<stdlib.h>

main()

{
	int vetor[10], x;
	int A = 0;
	int B = 0;
	int C = 0;
//A = lucro menor de 10%; B = lucro <= 20%; C = lucro igual ou superior a 20 %;
	float compra[100], venda[100], porcento, porcentagemlucro[100];
	
	printf("\n*****LISTA DE MERCADORIA*****\n\n");
	
	for( x = 0 ; x < 100 ; x++ )
		{
			printf("\n %d Produto \n", x+1);
			printf(" Pre�o de COMPRA da mercadoria: R$ ");
			scanf("%f", &compra[x]);
			printf(" Pre�o de VENDA da mercadoria: R$ ");
			scanf("%f", &venda[x]);
			
			porcento = ( venda[x] / compra[x] ) -1;
			porcentagemlucro[x] = porcento * 100;
			
			if ( porcento < 0.1 )
			{
				A++;
			}
			else
				if( porcento <= 0.2 )
				{
					B++;
				}
			else
				{
					C++;
				}
	printf("\n");
		}

	printf("\n********************************************************");
	printf("\n\n*******RELATORIO COMPLETO*********\n");
	printf("\n Margem de lucro inferior a 10%% = %d produto(s). \n", A);
	printf("\n Margem de lucro igual ou superior a 10%% e inferior a 20%% = %d produto(s). \n", B);
	printf("\n Margem de lucro igual ou superior a 20%% = %d produto(s). \n", C);
	printf("\n");
	printf("*********************************************************\n");	
	
	for ( x = 0 ; x < 100 ; x++ )
	{	
		printf("PRODUTO %d - Compra R$ %.2f - Venda R$ %.2f - Margem de lucro: %.2f%%\n",x+1,compra[x], venda[x], porcentagemlucro[x]);
	}	
}
