//Quest�o 02 
//Fa�a um programa que cria um vetor com 5 elementos inteiros, l� 5 n�meros do teclado, armazena os n�meros no vetor e imprime o vetor na ordem inversa.

#include<stdio.h>
#include<stdlib.h>

int main()

{
	int vetor[5], x;
	
	printf("\n*PROGRAMA DIGITE NUMEROS em ORDEM ALEATORIO E MOSTRA A ORDEM INVERSA*\n");
	
	for ( x = 0 ; x < 5 ; x++ )
	{
		printf("\nEscreva um numero na posi��o  %d = \t", x+1);
		scanf("%d", &vetor[x]);
	}
	
	printf("\n\nVALORES INVERSOS\n");
	
	for( x = 4 ; x >= 0 ; x-- )
	{
		printf("  Posicao   %d   \n", vetor[x]);	
	}
	
}
