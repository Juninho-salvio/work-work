//Quest�o 04 
//Dados dois vetores, A (5 elementos) e B (8 elementos), fa�a um programa que imprima todos os elementos comuns aos dois vetores.

#include<stdio.h>
#include<stdlib.h>

main()

{
	int vetorA[5], vetorB[8], x, y;


	printf("\n*******Digite 5 numeros******\n\n");
//numeros apenas do vetor A;	
	for( x = 0 ; x < 5 ; x++ )
	{
		printf("Posicao %d = ", x+1);
		scanf("%d", &vetorA[x]);
	}
	printf("\n\n");
	
	printf("\n*******Digite 8 numeros******\n\n");
//numeros apenas do vetor B;
	for( y = 0 ; y < 8 ; y++ )
	{
		printf("Posicao %d = ", y+1);
		scanf("%d", &vetorB[y]);	
	}
//vetores em comun
	for( x = 0 ; x < 5 ; x++ )
		for( y = 0 ; y < 8 ; y++ )
			if( vetorA[x] == vetorB[y])
			{
				printf("\nNumero  %d  e comun nos dois vetores", vetorA[x]);
			}
	printf("\n");
	
}
