/*Quest�o 06 
Dois vetores possuem 30 elementos cada, contendo: c�digo (c�digo[30]) e telefone (tel[30]) 
Fa�a um programa que permita buscar pelo c�digo e imprimir o telefone.*/

#include<stdio.h>
#include<stdlib.h>

main()

{
	int codigo[30], telefone[30], x, cod;
//Escrevendo os codigos e telefones
	for( x = 0 ; x < 30 ; x++ )
	{
		printf("\nEscreva o codigo %d para o primeiro telefone = ", x+1);
		scanf("%d", &codigo[x]);
		printf("\nEscreva o telefone = ");
		scanf("%d", &telefone[x]);
		printf("\n");
	}
//digitar o codigo para procura
	printf("\n\nPara buscar o telefone do usuario, digite seu codigo = ");
	scanf("%d", &cod);
	printf("\n\n");
//mostrar o telefone desejado
	for( x = 0 ; x < 30 ; x++ )
	{
		if( cod == codigo[x] )
		{
			printf(" O telefone correspondente do usuario = %d\n", telefone[x]);
		}
	}		
	printf("\n");
}
